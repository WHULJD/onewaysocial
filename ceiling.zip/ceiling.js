// JavaScript Document
$(document).ready(function(){
	$("#combo ul").width($("#combo").width());
	$("#combo ul li").width($("#combo").width());

});

